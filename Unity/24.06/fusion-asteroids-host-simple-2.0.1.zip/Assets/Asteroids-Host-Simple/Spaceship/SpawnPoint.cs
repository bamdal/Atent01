using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Asteroids.HostSimple
{
    // Uses exclusively to tag SpawnPoints in order to be able to gather all of them programmatically in SpaceshipSpawner.cs
    public class SpawnPoint : MonoBehaviour
    {
    }
}